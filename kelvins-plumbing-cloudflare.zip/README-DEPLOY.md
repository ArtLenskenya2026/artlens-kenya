# Kelvins Plumbing Works – Cloudflare Pages Deployment

Ready-to-upload static site for **kelvinsplumbimbing.com**.

No GitHub, no build step, no Node/npm required.

---

## What’s included

- `index.html` – Home
- `services.html` – Services + request form
- `gallery.html` – Gallery (placeholder ready for real job photos)
- `about.html` – About + FAQs
- `404.html` – Not-found page
- `images/logo.png` – Transparent logo
- `css/styles.css` & `js/main.js`
- `_redirects` – Clean URLs on Cloudflare Pages
- `robots.txt`

Colour scheme: orange `#f26722`, dark `#211a15`, cream backgrounds. Logo background removed (transparent PNG).

---

## Deploy on Cloudflare Pages (no Git)

### Option A – Direct upload (recommended)

1. Log in to [Cloudflare Dashboard](https://dash.cloudflare.com) → **Workers & Pages**.
2. Click **Create** → **Pages** → **Upload assets**.
3. Project name: e.g. `kelvins-plumbing`.
4. Drag & drop the **entire contents** of this folder (or zip the folder and upload).
5. Click **Deploy site**.

### Option B – Wrangler CLI (optional)

```bash
npx wrangler pages deploy . --project-name=kelvins-plumbing
```

---

## Point your domain (kelvinsplumbimbing.com)

1. In Cloudflare Pages project → **Custom domains** → **Set up a custom domain**.
2. Enter `kelvinsplumbimbing.com` (and optionally `www.kelvinsplumbimbing.com`).
3. Cloudflare will show the DNS records needed.
4. At **Freehostia** (where the domain is registered):
   - Either change nameservers to Cloudflare’s (recommended – full CDN + free SSL),  
     **or**
   - Add a CNAME / A record pointing to the Cloudflare Pages target they show you.
5. Wait for DNS propagation (usually a few minutes to a couple of hours). SSL is automatic.

---

## After deploy

- Contact form opens the visitor’s email client with a pre-filled message to `info@kelvinsplumbimbing.com`.  
  Change the email address in `services.html` and `js/main.js` if needed.
- Gallery page is ready for real job photos – just replace the placeholder section with an image grid when you have them.
- No server, no database, no dependencies. Pure static files.

---

## Local preview

Open `index.html` in a browser, or run a simple local server:

```bash
# Python
python3 -m http.server 8080

# or Node
npx serve .
```

Then visit http://localhost:8080
